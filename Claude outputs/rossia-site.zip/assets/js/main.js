(function () {
  var C = window.ROSSIA || {};
  var num = String(C.whatsapp || "").replace(/\D/g, "");
  // De onde o visitante veio (ex.: link com ?utm_source=instagram)
  var campanha = "";
  try {
    var q = new URLSearchParams(location.search);
    var src = [q.get("utm_source"), q.get("utm_campaign")].filter(Boolean).join(" / ");
    if (src) sessionStorage.setItem("rossia_src", src);
    campanha = sessionStorage.getItem("rossia_src") || "";
  } catch (e) {}
  function wa(msg, origem) {
    var txt = msg || C.mensagem || "";
    if (C.mostrarOrigem !== false && origem) txt += "\n\n[Origem: Site RossIA › " + origem + (campanha ? " · Campanha: " + campanha : "") + "]";
    return "https://wa.me/" + num + "?text=" + encodeURIComponent(txt);
  }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function icon(id) { return '<svg><use href="#i-' + id + '"/></svg>'; }

  // Links de WhatsApp
  document.querySelectorAll(".js-wa").forEach(function (a) {
    a.href = wa(a.getAttribute("data-msg"), a.getAttribute("data-origem"));
    a.target = "_blank"; a.rel = "noopener";
  });

  // E-mail e ano
  var fm = document.getElementById("footMail");
  if (fm && C.email) { fm.hidden = false; fm.href = "mailto:" + C.email; fm.textContent = C.email; }
  var y = document.getElementById("year"); if (y) y.textContent = new Date().getFullYear();

  // Menu
  var nav = document.querySelector(".nav"), links = document.getElementById("navLinks"), tg = document.getElementById("navToggle");
  tg.addEventListener("click", function () {
    var o = links.classList.toggle("open");
    tg.innerHTML = icon(o ? "x" : "menu"); tg.setAttribute("aria-label", o ? "Fechar menu" : "Abrir menu");
  });
  links.querySelectorAll("a").forEach(function (a) { a.addEventListener("click", function () { links.classList.remove("open"); tg.innerHTML = icon("menu"); }); });
  function onScroll() { nav.classList.toggle("scrolled", window.scrollY > 8); }
  window.addEventListener("scroll", onScroll, { passive: true }); onScroll();

  // ===== Cookies (LGPD) =====
  var CK = "rossia_cookies";
  function getConsent() { try { return localStorage.getItem(CK); } catch (e) { return null; } }
  function setConsent(v) { try { localStorage.setItem(CK, v); } catch (e) {} }
  var loadedOptional = false;
  function loadOptional() {
    if (loadedOptional) return; loadedOptional = true;
    var f = document.createElement("link"); f.rel = "stylesheet";
    f.href = "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap";
    document.head.appendChild(f);
    if (C.googleAnalytics) {
      var g = document.createElement("script"); g.async = true; g.src = "https://www.googletagmanager.com/gtag/js?id=" + C.googleAnalytics; document.head.appendChild(g);
      window.dataLayer = window.dataLayer || []; window.gtag = function () { dataLayer.push(arguments); };
      gtag("js", new Date()); gtag("config", C.googleAnalytics, { anonymize_ip: true });
    }
    if (C.metaPixel) {
      !function (f, b, e, v, n, t, s) { if (f.fbq) return; n = f.fbq = function () { n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments); }; if (!f._fbq) f._fbq = n; n.push = n; n.loaded = !0; n.version = "2.0"; n.queue = []; t = b.createElement(e); t.async = !0; t.src = v; s = b.getElementsByTagName(e)[0]; s.parentNode.insertBefore(t, s); }(window, document, "script", "https://connect.facebook.net/en_US/fbevents.js");
      fbq("init", C.metaPixel); fbq("track", "PageView");
    }
  }
  var bar = document.getElementById("cookieBar");
  function showBar() { if (bar) { bar.hidden = false; requestAnimationFrame(function () { bar.classList.add("show"); }); } }
  function hideBar() { if (bar) { bar.classList.remove("show"); bar.hidden = true; } }
  if (bar) {
    document.getElementById("cookieYes").addEventListener("click", function () { setConsent("all"); hideBar(); loadOptional(); });
    document.getElementById("cookieNo").addEventListener("click", function () { setConsent("essential"); hideBar(); });
    var cp = document.getElementById("cookiePrefs");
    if (cp) cp.addEventListener("click", function (e) { e.preventDefault(); showBar(); });
    var cur = getConsent();
    if (cur === "all") loadOptional(); else if (!cur) setTimeout(showBar, 600);
  }
  // Quem clicou no WhatsApp (só com consentimento)
  document.addEventListener("click", function (e) {
    var a = e.target.closest && e.target.closest('a[href^="https://wa.me/"]');
    if (!a || getConsent() !== "all") return;
    var label = a.getAttribute("data-origem") || a.textContent.trim();
    if (window.gtag) gtag("event", "clique_whatsapp", { origem: label });
    if (window.fbq) fbq("track", "Contact", { origem: label });
  });

  // Planos
  function priceHtml(p, per) {
    if (!p) return '<span class="ask">Sob consulta</span>';
    var parts = String(p).split(",");
    return '<span class="cur">R$</span><span class="val">' + esc(parts[0]) + (parts[1] ? '<small style="font-size:.5em">,' + esc(parts[1]) + "</small>" : "") + '</span><span class="per">' + esc(per || "") + "</span>";
  }
  var box = document.getElementById("plans");
  if (box && C.planos) {
    box.innerHTML = C.planos.map(function (p) {
      var msg = "Olá! Tenho interesse no plano " + p.nome + " da RossIA.";
      return '<div class="plan reveal' + (p.destaque ? " hl" : "") + '">' +
        (p.destaque ? '<span class="badge">Mais escolhido</span>' : "") +
        "<h3>" + esc(p.nome) + '</h3><p class="pub">' + esc(p.publico) + "</p>" +
        '<div class="price">' + priceHtml(p.preco, p.periodo) + "</div>" +
        '<p class="impl">' + esc(p.implantacao || "") + "</p>" +
        "<ul>" + (p.itens || []).map(function (i) { return "<li>" + icon("check") + "<span>" + esc(i) + "</span></li>"; }).join("") + "</ul>" +
        '<a class="btn btn-primary" target="_blank" rel="noopener" href="' + wa(msg, "Planos › " + p.nome) + '">Quero este plano</a></div>';
    }).join("");
  }

  // Parceiro
  var pc = document.getElementById("partnerCta"), P = C.parceiro || {};
  if (pc) {
    pc.innerHTML = "<div><h4>" + esc(P.titulo || "Seja um parceiro") + "</h4><p>" + esc(P.texto || "") + "</p>" +
      (P.preco ? '<div class="price">R$ ' + esc(P.preco) + " <small>" + esc(P.periodo || "") + "</small></div>" : "") + "</div>" +
      '<a class="btn btn-light" target="_blank" rel="noopener" href="' + wa(C.mensagemParceiro, "Seção Parceiros") + '">' + icon("chat") + (P.preco ? " Quero ser parceiro" : " Fale com a gente") + "</a>";
  }

  // Animação de entrada
  var io = "IntersectionObserver" in window ? new IntersectionObserver(function (es) {
    es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add("on"); io.unobserve(e.target); } });
  }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }) : null;
  document.querySelectorAll(".reveal").forEach(function (el) { io ? io.observe(el) : el.classList.add("on"); });

  // Zoom das telas
  var lb = document.getElementById("lightbox");
  if (lb) {
    var lbImg = lb.querySelector("img");
    document.querySelectorAll(".shot img").forEach(function (im) {
      im.addEventListener("click", function () { lbImg.src = im.currentSrc || im.src; lbImg.alt = im.alt; lb.hidden = false; document.body.style.overflow = "hidden"; });
    });
    function closeLb() { lb.hidden = true; document.body.style.overflow = ""; }
    lb.addEventListener("click", closeLb);
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") closeLb(); });
  }

  // ===== Demonstração por segmento =====
  var AI = '<span class="tag">' + icon("spark") + " IA</span>";
  function svgUri(svg) { return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg); }
  var IMG_TENIS = svgUri('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 440 330"><rect width="440" height="330" fill="#eef2f7"/><ellipse cx="220" cy="262" rx="170" ry="14" fill="#d5dce6"/><path d="M70 230c0-40 20-90 60-110 22-11 48 6 70 18 30 17 70 30 110 38 40 8 70 20 70 54v14H70z" fill="#fff" stroke="#cbd5e1" stroke-width="4"/><path d="M70 232h310v22c0 6-4 10-10 10H80c-6 0-10-4-10-10z" fill="#0f3b52"/><path d="M160 135l20 55M190 148l18 50M222 160l14 45" stroke="#8b2cf5" stroke-width="7" stroke-linecap="round"/><path d="M290 190c30 6 60 14 80 26" stroke="#155e75" stroke-width="10" stroke-linecap="round" fill="none"/></svg>');
  var IMG_BURGER = svgUri('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 440 330"><rect width="440" height="330" fill="#fdf2e3"/><ellipse cx="220" cy="272" rx="150" ry="14" fill="#f1dcc0"/><path d="M100 150c0-60 55-95 120-95s120 35 120 95z" fill="#e5a14a"/><g fill="#fff6e0"><ellipse cx="170" cy="100" rx="6" ry="3"/><ellipse cx="220" cy="85" rx="6" ry="3"/><ellipse cx="265" cy="105" rx="6" ry="3"/><ellipse cx="200" cy="120" rx="6" ry="3"/></g><path d="M92 160h256l-12 18H104z" fill="#6cc04a"/><path d="M96 178h248l-20 16H116z" fill="#f4c430"/><rect x="100" y="192" width="240" height="30" rx="14" fill="#6b3a22"/><path d="M104 226h232v12c0 18-20 30-40 30H144c-20 0-40-12-40-30z" fill="#e5a14a"/></svg>');
  var IMG_RECEITA = svgUri('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 440 330"><rect width="440" height="330" fill="#e7e2d8"/><g transform="rotate(-4 220 165)"><rect x="110" y="30" width="220" height="270" rx="6" fill="#fff"/><text x="132" y="78" font-family="Arial" font-size="30" font-weight="700" fill="#155e75">Rx</text><rect x="132" y="98" width="170" height="8" rx="4" fill="#cbd5e1"/><rect x="132" y="126" width="150" height="8" rx="4" fill="#cbd5e1"/><rect x="132" y="154" width="165" height="8" rx="4" fill="#cbd5e1"/><rect x="132" y="182" width="110" height="8" rx="4" fill="#cbd5e1"/><path d="M190 255c15-20 30 10 45-8s25 5 40-6" stroke="#1e3a8a" stroke-width="3" fill="none"/><rect x="180" y="265" width="110" height="3" fill="#94a3b8"/></g></svg>');

  var SEGMENTS = [
    { id: "scooter", label: "Loja de scooters", icon: "scooter", title: "Loja de scooters elétricas",
      why: "O cliente quer saber preço, cor, prazo e parcelas na hora, e muitos chamam fora do horário.",
      ben: "A IA mostra a foto, tira as dúvidas e marca o test-drive. O vendedor só fecha.",
      checks: ["Envia a foto da cor que o cliente pediu", "Avisa quando é sob reserva e o prazo", "Informa as parcelas", "Marca o test-drive e move o card no funil"],
      contact: "Mariana", funnel: "Scooters", cols: ["Primeiro contato", "Test-drive", "Reserva", "Vendas"],
      interest: "Scooter Urban X1 · vermelha", score: 82, level: "Quente",
      resumo: "Quer a Urban X1 vermelha (reserva, 15 dias). Test-drive sábado 10h em Itápolis.",
      script: [
        { t: "in", h: "Oi! Quanto tá a scooter Urban X1?", at: "09:12" },
        { t: "out", h: AI + "Oi! 😊 A <b>Urban X1</b> está de R$ 12.990 por <b>R$ 11.490 à vista</b>, ou em até 21x de R$ 547,14 sem juros. Tem nas cores azul, preta e vermelha. Quer ver uma foto?", at: "09:12" },
        { t: "in", h: "Quero! Tem vermelha?", at: "09:13" },
        { t: "img", src: "assets/img/scooter-vermelha.webp", h: "Scooter Urban X1 — Vermelha<br>Sob reserva · entrega em até 15 dias", at: "09:13" },
        { t: "out", h: AI + "Tem sim! A vermelha é <b>sob reserva</b>, com entrega em até 15 dias. A azul e a preta são pronta entrega. E não precisa de habilitação: é autopropelido, até 32 km/h.", at: "09:13" },
        { t: "audio", h: "“Show! Dá pra testar antes? Sábado de manhã eu consigo.”", at: "09:14" },
        { t: "out", h: AI + "Dá sim! Tenho <b>sábado às 10h</b> na loja de Itápolis. Posso confirmar seu test-drive?", at: "09:14" },
        { t: "in", h: "Pode confirmar 👍", at: "09:15" },
        { t: "sys", h: icon("cal") + " Test-drive agendado · sáb 10:00", cls: "green", move: 1, action: "Test-drive", agenda: "Sáb 10:00" },
        { t: "out", h: AI + "Confirmado, Mariana! ✅ Sábado às 10h. Vou te mandar um lembrete antes. Até lá!", at: "09:15" }
      ] },
    { id: "clinica", label: "Clínicas", icon: "steth", title: "Clínicas e consultórios",
      why: "Muitas remarcações de última hora, confirmação de consultas e dúvidas sobre exames.",
      ben: "Menos faltas e agenda cheia, com confirmação e lembrete automáticos.",
      checks: ["Marca e remarca consultas na agenda", "Envia lembrete e pede confirmação", "Passa as orientações de exame cadastradas pela clínica", "Urgência? Passa na hora para a recepção"],
      contact: "Carlos", funnel: "Atendimentos", cols: ["Novo contato", "Consulta agendada", "Confirmada", "Retorno"],
      interest: "Consulta · Dra. Paula", score: 90, level: "Confirmado",
      resumo: "Remarcou a consulta de quinta para sexta 14h. Orientado sobre o jejum do exame.",
      script: [
        { t: "in", h: "Boa tarde! Preciso remarcar minha consulta de quinta com a Dra. Paula", at: "14:02" },
        { t: "out", h: AI + "Boa tarde, Carlos! Claro. A Dra. Paula tem horário na <b>sexta às 14h</b> ou na <b>segunda às 9h30</b>. Qual fica melhor pra você?", at: "14:02" },
        { t: "in", h: "Sexta 14h", at: "14:03" },
        { t: "sys", h: icon("cal") + " Consulta remarcada · sex 14:00", cls: "green", move: 1, action: "Agendar consulta", agenda: "Sex 14:00" },
        { t: "out", h: AI + "Pronto! ✅ Consulta remarcada para <b>sexta às 14h</b>. Lembrando: o exame de sangue pede <b>jejum de 8 horas</b>. Te mando um lembrete na véspera.", at: "14:03" },
        { t: "in", h: "Perfeito, obrigado! Confirmado.", at: "14:04" },
        { t: "sys", h: icon("kanban") + " Card movido para Confirmada", move: 2 }
      ] },
    { id: "ecommerce", label: "E-commerce", icon: "cart", title: "E-commerce e varejo online",
      why: "Clientes ansiosos perguntam sobre produto, tamanho, pagamento e entrega.",
      ben: "Resposta na hora aumenta a conversão e reduz o abandono do carrinho.",
      checks: ["Manda foto, tamanhos e cores do catálogo", "Explica frete, Pix e parcelas", "Envia o link para finalizar a compra", "Dúvida sobre pedido? Anota e passa para a equipe"],
      contact: "Júlia", funnel: "Loja online", cols: ["Dúvida", "Checkout", "Venda", "Pós-venda"],
      interest: "Tênis Run Pro · 38", score: 88, level: "Quente",
      resumo: "Quer o Run Pro branco nº 38 no Pix. Link de compra enviado, pedido finalizado.",
      script: [
        { t: "in", h: "Oi! Esse tênis Run Pro tem no 38?", at: "20:41" },
        { t: "img", src: IMG_TENIS, h: "Tênis Run Pro — Branco<br>Nº 34 ao 42 · pronta entrega", at: "20:41" },
        { t: "out", h: AI + "Tem sim, Júlia! 😊 O <b>Run Pro branco</b> nº 38 está disponível: <b>R$ 299,90 no Pix</b> ou 6x de R$ 49,98. E o frete é grátis acima de R$ 250!", at: "20:41" },
        { t: "in", h: "Amei! Como eu compro?", at: "20:42" },
        { t: "out", h: AI + "É só finalizar por este link: <u>sualoja.com.br/runpro-38</u> 🛒 Se tiver qualquer dúvida no pagamento, estou aqui.", at: "20:42" },
        { t: "sys", h: icon("zap") + " Link enviado · card em Checkout", move: 1, action: "Enviar link de compra" },
        { t: "in", h: "Comprei! 🎉", at: "20:47" },
        { t: "sys", h: icon("check") + " Venda registrada", cls: "green", move: 2 }
      ] },
    { id: "provedor", label: "Provedor de internet", icon: "wifi", title: "Provedores de internet",
      why: "Queda de sinal gera insatisfação imediata e fila no suporte técnico.",
      ben: "Resolve o básico na hora, agenda o técnico e reduz as ligações no suporte.",
      checks: ["Faz o passo a passo inicial com o cliente", "Entende áudio e foto do roteador", "Agenda a visita técnica", "Passa para o técnico quando precisa"],
      contact: "Roberto", funnel: "Suporte", cols: ["Novo chamado", "Em teste", "Visita técnica", "Resolvido"],
      interest: "Sem conexão · fibra", score: 95, level: "Urgente",
      resumo: "Sem internet há 1h, luz PON vermelha após reiniciar. Visita técnica hoje 16h.",
      script: [
        { t: "in", h: "Minha internet caiu faz uma hora 😤", at: "10:05" },
        { t: "out", h: AI + "Poxa, Roberto, vamos resolver! Faz um teste rápido pra mim: <b>desligue o roteador da tomada por 30 segundos</b> e ligue de novo. Depois me conta a cor da luz <b>PON</b>.", at: "10:05" },
        { t: "sys", h: icon("kanban") + " Card movido para Em teste", move: 1 },
        { t: "audio", h: "“Desliguei e liguei, e a luz tá piscando vermelho.”", at: "10:08" },
        { t: "out", h: AI + "Obrigado! Luz vermelha indica problema no sinal da fibra, precisa de um técnico. Tenho <b>visita hoje às 16h</b>. Posso confirmar?", at: "10:08" },
        { t: "in", h: "Pode sim", at: "10:09" },
        { t: "sys", h: icon("cal") + " Visita técnica agendada · hoje 16:00", cls: "green", move: 2, action: "Visita técnica", agenda: "Hoje 16:00" }
      ] },
    { id: "farmacia", label: "Farmácias", icon: "pill", title: "Farmácias e drogarias",
      why: "Pedido de remédio é urgente, e o cliente quer resposta e entrega rápidas.",
      ben: "Atendimento na hora fideliza quem busca entrega imediata.",
      checks: ["Recebe a foto da receita", "Informa entrega, prazo e formas de pagamento", "Remédio com receita? O farmacêutico confere antes", "Manipulação: passa o orçamento para a equipe"],
      contact: "Célia", funnel: "Pedidos", cols: ["Novo pedido", "Conferência", "Saiu para entrega", "Entregue"],
      interest: "Pedido com receita", score: 92, level: "Quente",
      resumo: "Enviou receita, conferida pelo farmacêutico. Pagamento no cartão na entrega.",
      script: [
        { t: "in", h: "Boa noite, vocês entregam? Preciso desse aqui", at: "21:10" },
        { t: "imgin", src: IMG_RECEITA, h: "", at: "21:10" },
        { t: "out", h: AI + "Boa noite, Célia! Entregamos sim 🛵 em até <b>40 minutos</b> no seu bairro. Como é medicamento com receita, nosso <b>farmacêutico vai conferir</b> e já te passa o valor.", at: "21:10" },
        { t: "sys", h: icon("hand") + " Passado para o farmacêutico", move: 1, action: "Passar para farmacêutico" },
        { t: "human", who: "Paulo · farmacêutico", h: "Conferido, Célia! Total <b>R$ 38,70</b>. Pode ser Pix ou cartão na entrega.", at: "21:13" },
        { t: "in", h: "Cartão na entrega", at: "21:14" },
        { t: "sys", h: icon("check") + " Card movido para Saiu para entrega", cls: "green", move: 2 }
      ] },
    { id: "delivery", label: "Delivery", icon: "food", title: "Delivery e restaurantes",
      why: "No horário de pico, demora para responder vira reclamação na hora e pedido perdido.",
      ben: "A IA anota o pedido, confirma endereço e pagamento e manda direto para a cozinha.",
      checks: ["Mostra o cardápio com fotos e preços", "Monta o pedido e soma o total com a taxa de entrega", "Confirma endereço, troco e forma de pagamento", "Pedido salvo e card direto em Em preparo"],
      contact: "Lucas", funnel: "Pedidos", cols: ["Novo pedido", "Em preparo", "Saiu para entrega", "Entregue"],
      interest: "2 X-Burger + 1 refri", score: 94, level: "Pedido fechado",
      resumo: "2 X-Burger especial + Coca 2L. Total R$ 72,80. Pix na entrega. Rua das Flores, 120.",
      script: [
        { t: "in", h: "Boa noite! Quero 2 X-Burger e uma Coca 2L", at: "20:15" },
        { t: "img", src: IMG_BURGER, h: "X-Burger especial — R$ 29,90<br>Pão brioche, 150g, cheddar e bacon", at: "20:15" },
        { t: "out", h: AI + "Boa noite, Lucas! 🍔 Anotado:<br>• 2x X-Burger especial — R$ 59,80<br>• 1x Coca-Cola 2L — R$ 7,00<br>• Entrega — R$ 6,00<br><b>Total: R$ 72,80</b><br>Qual o endereço e a forma de pagamento?", at: "20:15" },
        { t: "audio", h: "“Rua das Flores, 120, perto da praça. Pago no Pix.”", at: "20:16" },
        { t: "out", h: AI + "Perfeito! Entrega na <b>Rua das Flores, 120</b>, pagamento no <b>Pix</b>. Previsão: <b>35 a 45 minutos</b>. Posso confirmar o pedido?", at: "20:16" },
        { t: "in", h: "Confirma!", at: "20:16" },
        { t: "sys", h: icon("check") + " Pedido salvo · enviado para a cozinha", cls: "green", move: 1, action: "Pedido confirmado", agenda: "Entrega ~20:55" },
        { t: "out", h: AI + "Pedido confirmado! ✅ Já está na cozinha. Te aviso quando sair para entrega. Bom apetite! 😋", at: "20:17" }
      ] }
  ];

  var body = document.getElementById("chatBody"), status = document.getElementById("chatStatus");
  var tabs = document.getElementById("segTabs"), copy = document.getElementById("segCopy"), panel = document.getElementById("segPanel");
  var timer = null, current = SEGMENTS[0];
  function scroll() { body.scrollTop = body.scrollHeight; }
  function add(html) { var d = document.createElement("div"); d.innerHTML = html; var el = d.firstChild; body.appendChild(el); scroll(); return el; }
  function render(m) {
    if (m.t === "sys") return '<div class="sys ' + (m.cls || "") + '">' + m.h + "</div>";
    if (m.t === "img") return '<div class="msg out img"><img src="' + m.src + '" alt="Foto enviada pela IA" width="220" height="165"><p>' + m.h + "</p><time>" + m.at + "</time></div>";
    if (m.t === "imgin") return '<div class="msg in img"><img src="' + m.src + '" alt="Foto enviada pelo cliente" width="220" height="165"><time>' + m.at + "</time></div>";
    if (m.t === "audio") return '<div class="msg in audio"><div class="wave"><span class="play"></span><span class="bars"></span><small>0:06</small></div><span class="tr">' + m.h + "</span><time>" + m.at + "</time></div>";
    if (m.t === "human") return '<div class="msg out human"><span class="tag">' + icon("users") + " " + esc(m.who) + "</span>" + m.h + "<time>" + m.at + "</time></div>";
    return '<div class="msg ' + m.t + '">' + m.h + "<time>" + m.at + "</time></div>";
  }

  function renderCopy(sg) {
    copy.innerHTML = '<div class="fade-in"><span class="seg-icon">' + icon(sg.icon) + "</span><h3>" + esc(sg.title) + "</h3>" +
      '<div class="seg-why"><div><b>Por que precisa</b><span>' + esc(sg.why) + '</span></div><div class="ben"><b>Com a RossIA</b><span>' + esc(sg.ben) + "</span></div></div>" +
      '<ul class="checks">' + sg.checks.map(function (c) { return "<li>" + icon("check") + "<span>" + esc(c) + "</span></li>"; }).join("") + "</ul>" +
      '<div class="seg-ctas"><a class="btn btn-primary" target="_blank" rel="noopener" href="' + wa("Olá! Quero a RossIA para o meu negócio: " + sg.title + ".", "Exemplo por segmento › " + sg.title) + '">' + icon("chat") + " Quero para o meu negócio</a>" +
      '<button class="btn btn-light" type="button" id="replay">' + icon("arrow") + " Ver de novo</button></div></div>";
    document.getElementById("replay").addEventListener("click", function () { play(current); });
  }
  function renderPanel(sg) {
    panel.innerHTML =
      '<div class="pm-card fade-in"><div class="pm-title">Ficha do lead <span class="chip">' + icon("chat") + ' WhatsApp</span></div>' +
      '<div class="pm-lead"><span class="avatar">' + esc(sg.contact[0]) + "</span><div><b>" + esc(sg.contact) + "</b><small>Entrou agora</small></div></div>" +
      '<div class="pm-q"><div class="lab">' + icon("spark") + ' QUALIFICAÇÃO DA IA</div><div class="row"><span id="pmLevel">—</span><span id="pmScore">0/100</span></div>' +
      '<div class="pm-bar"><i id="pmBar"></i></div><p id="pmResumo">A IA ainda não resumiu este atendimento.</p></div>' +
      '<div class="pm-fields"><div><span>Interesse</span><b>' + esc(sg.interest) + '</b></div><div><span>Ação</span><b id="pmAction"><span class="chip chip-wait">aguardando</span></b></div><div><span>Agenda</span><b id="pmAgenda">—</b></div></div></div>' +
      '<div class="pm-card fade-in"><div class="pm-title">Funil · ' + esc(sg.funnel) + '</div><div class="pm-cols">' +
      sg.cols.map(function (c, i) { return '<div class="pm-col" data-i="' + i + '"><span><span class="dot" style="background:' + ["#0ea5e9", "#8b5cf6", "#f97316", "#10b981"][i % 4] + '"></span>' + esc(c) + '</span><em>0</em><span class="mini-card"><span class="avatar" style="width:16px;height:16px;font-size:.6rem">' + esc(sg.contact[0]) + "</span>" + esc(sg.contact) + "</span></div>"; }).join("") +
      "</div></div>";
    moveTo(0);
  }
  function moveTo(i) {
    panel.querySelectorAll(".pm-col").forEach(function (c) { c.classList.toggle("has", +c.getAttribute("data-i") === i); });
  }
  function applySys(m) {
    if (m.move != null) moveTo(m.move);
    if (m.action) document.getElementById("pmAction").innerHTML = '<span class="chip chip-ai">' + icon("zap") + " " + esc(m.action) + "</span>";
    if (m.agenda) document.getElementById("pmAgenda").textContent = m.agenda;
  }
  function finish(sg) {
    document.getElementById("pmScore").textContent = sg.score + "/100";
    document.getElementById("pmLevel").textContent = sg.level;
    document.getElementById("pmBar").style.width = sg.score + "%";
    document.getElementById("pmResumo").textContent = sg.resumo;
  }
  function play(sg) {
    current = sg; clearTimeout(timer); body.innerHTML = "";
    document.getElementById("chatName").textContent = sg.contact;
    document.getElementById("chatAvatar").textContent = sg.contact[0];
    renderCopy(sg); renderPanel(sg);
    tabs.querySelectorAll(".seg-tab").forEach(function (b) { b.setAttribute("aria-selected", b.getAttribute("data-id") === sg.id ? "true" : "false"); });
    var i = 0;
    (function next() {
      if (i >= sg.script.length) { status.textContent = "online"; timer = setTimeout(function () { finish(sg); }, 300); return; }
      var m = sg.script[i++], incoming = m.t === "in" || m.t === "audio" || m.t === "imgin";
      if (m.t === "sys") { add(render(m)); applySys(m); timer = setTimeout(next, 1000); return; }
      status.textContent = incoming ? (m.t === "audio" ? "gravando áudio…" : "digitando…") : "online";
      var ty = add('<div class="typing ' + (incoming ? "in" : "") + '"><i></i><i></i><i></i></div>');
      timer = setTimeout(function () {
        ty.remove(); status.textContent = "online"; add(render(m));
        if (i >= 3 && i === Math.ceil(sg.script.length / 2)) { document.getElementById("pmScore").textContent = Math.round(sg.score * 0.6) + "/100"; document.getElementById("pmBar").style.width = Math.round(sg.score * 0.6) + "%"; document.getElementById("pmLevel").textContent = "Morno"; }
        timer = setTimeout(next, incoming ? 700 : 1300);
      }, incoming ? 1100 : 1500);
    })();
  }
  tabs.innerHTML = SEGMENTS.map(function (sg) {
    return '<button class="seg-tab" type="button" role="tab" data-id="' + sg.id + '" aria-selected="false">' + icon(sg.icon) + esc(sg.label) + "</button>";
  }).join("");
  var started = false;
  tabs.querySelectorAll(".seg-tab").forEach(function (b) {
    b.addEventListener("click", function () { started = true; var sg = SEGMENTS.filter(function (x) { return x.id === b.getAttribute("data-id"); })[0]; play(sg); });
  });
  renderCopy(current); renderPanel(current);
  tabs.firstChild.setAttribute("aria-selected", "true");
  if ("IntersectionObserver" in window) {
    new IntersectionObserver(function (es) { if (es[0].isIntersecting && !started) { started = true; play(current); } }, { threshold: 0.35 }).observe(body);
  } else play(current);
})();
