/* =====================================================================
   RossIA — CONFIGURAÇÃO DO SITE
   Este é o ÚNICO arquivo que você precisa editar.
   Troque os textos entre aspas e salve. Não apague vírgulas nem chaves.
   ===================================================================== */
window.ROSSIA = {
  // Número do WhatsApp com DDI + DDD, só números. Ex.: "5516999998888"
  whatsapp: "5516999999999",

  // Mensagem que já vem escrita quando a pessoa clica no botão
  mensagem: "Olá! Vi o site da RossIA e quero saber mais.",
  mensagemParceiro: "Olá! Quero ser parceiro revendedor da RossIA.",

  // E-mail que aparece no rodapé e na Política de Privacidade (deixe "" para esconder)
  email: "",

  // Dados da empresa para a Política de Privacidade
  empresa: "RossIA",          // razão social, ex.: "Fulano Tecnologia LTDA"
  cnpj: "",                   // ex.: "00.000.000/0001-00"
  cidade: "",                 // ex.: "Itápolis/SP"

  // Cada botão de WhatsApp envia no final da mensagem de onde a pessoa clicou.
  // Ex.: "[Origem: Site RossIA › Planos › Profissional]"
  mostrarOrigem: true,

  // Medição (opcional). Só carrega se o visitante ACEITAR os cookies.
  googleAnalytics: "",        // ex.: "G-XXXXXXXXXX"
  metaPixel: "",              // ex.: "123456789012345"

  /* ------------------------- PLANOS -------------------------
     ATENÇÃO: os valores abaixo são EXEMPLOS. Troque pelos seus.
     preco: só o número, com vírgula nos centavos (ex.: "297" ou "297,90").
            Deixe "" para mostrar "Sob consulta".
     destaque: true = cartão em destaque ("Mais escolhido").
  ----------------------------------------------------------- */
  planos: [
    {
      nome: "Essencial",
      publico: "Para começar a atender com IA",
      preco: "197",
      periodo: "/mês",
      implantacao: "Implantação: R$ 0",
      itens: [
        "1 número de WhatsApp",
        "IA atendendo 24h",
        "Catálogo com fotos e preços",
        "Funil de vendas e agenda",
        "Até 2 vendedores"
      ],
      destaque: false
    },
    {
      nome: "Profissional",
      publico: "Para quem vende todos os dias",
      preco: "397",
      periodo: "/mês",
      implantacao: "Implantação: R$ 0",
      itens: [
        "Tudo do Essencial",
        "IA ouve áudio e responde por voz",
        "Ações por produto (test-drive, reserva, reunião...)",
        "Vários funis",
        "Até 6 vendedores"
      ],
      destaque: true
    },
    {
      nome: "Completo",
      publico: "Todos os canais em um lugar",
      preco: "697",
      periodo: "/mês",
      implantacao: "Implantação: R$ 0",
      itens: [
        "Tudo do Profissional",
        "Instagram Direct e Messenger",
        "Vendedores ilimitados",
        "Relatórios por vendedor e funil",
        "Suporte prioritário"
      ],
      destaque: false
    }
  ],

  // Plano de parceiro revendedor (aparece na seção Parceiros)
  parceiro: {
    titulo: "Seja um parceiro RossIA",
    texto: "Revenda com a sua marca, defina seus preços e cuide dos seus clientes em um painel só seu.",
    preco: "",            // ex.: "990" — deixe "" para "Fale com a gente"
    periodo: "/mês"
  }
};
